package net.lrivas.miagenda.clases;

public class Configuraciones {
    public String urlWebServices;

    public Configuraciones(){
        this.urlWebServices = "http://192.168.1.11:8080/ws_app/webservices02.php";
    }
}
